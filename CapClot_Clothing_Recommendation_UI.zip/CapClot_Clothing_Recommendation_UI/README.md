# CapClot — Clothing Recommendation System

A beginner-friendly interactive clothing recommender built with Python, Pandas, and Streamlit.

## Features
- Filter by category, color, occasion, style, and maximum budget
- Rank catalog items using transparent preference-match scores
- View recommendations in a simple UI
- Download the recommendations as a CSV

## Run locally
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   python -m streamlit run app.py
   ```
5. Open the local URL shown in the terminal (usually http://localhost:8501).

## Files
- `app.py`: Streamlit user interface and recommendation function
- `clean_clothing_catalog.csv`: cleaned demo catalog
- `requirements.txt`: Python dependencies

## Important note
The included catalog is the small illustrative sample catalog from the starter notebook, not live store inventory. If you already have a larger cleaned catalog, replace this CSV with your file while keeping the required columns: `item_id`, `name`, `category`, `color`, `occasion`, `style`, and `price`.

## Tech stack
Python, Pandas, Streamlit, CSV

## Next improvements
- Add product photos and source links
- Add a larger real-world dataset with appropriate usage rights
- Add automated tests and improve recommendation ranking
