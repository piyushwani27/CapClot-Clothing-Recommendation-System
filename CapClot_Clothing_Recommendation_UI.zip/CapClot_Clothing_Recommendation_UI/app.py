import streamlit as st
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="CapClot | Clothing Recommender", page_icon="👕", layout="wide")

st.markdown("""
<style>
.main {background-color: #faf8f5;}
.hero {padding: 1.4rem 1.6rem; border-radius: 18px; background: linear-gradient(120deg,#1f2937,#52525b); color: white; margin-bottom: 1rem;}
.hero h1 {color: white; margin-bottom: .25rem;}
div[data-testid="stMetric"] {background: white; padding: 12px; border-radius: 12px; border: 1px solid #eee;}
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_catalog():
    path = Path(__file__).parent / "clean_clothing_catalog.csv"
    df = pd.read_csv(path)
    needed = ["item_id", "name", "category", "color", "occasion", "style", "price"]
    missing = [c for c in needed if c not in df.columns]
    if missing:
        raise ValueError("The CSV is missing required columns: " + ", ".join(missing))
    for col in ["name", "category", "color", "occasion", "style"]:
        df[col] = df[col].fillna("").astype(str).str.strip()
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    return df.dropna(subset=["price", "name", "category"]).drop_duplicates(subset=["item_id"])

def recommend_clothing(catalog, category, color, occasion, style, max_budget, top_n):
    results = catalog.copy()
    results["match_score"] = 0
    results["match_reasons"] = ""
    preferences = [("category", category, 3), ("color", color, 2),
                   ("occasion", occasion, 3), ("style", style, 2)]
    for column, preferred, points in preferences:
        if preferred != "Any":
            matches = results[column].fillna("").astype(str).str.casefold().eq(preferred.casefold())
            results.loc[matches, "match_score"] += points
            results.loc[matches, "match_reasons"] += f"{column.title()} match; "
    results = results[results["price"] <= max_budget].copy()
    return results.sort_values(["match_score", "price", "name"],
                               ascending=[False, True, True]).head(top_n)

try:
    catalog = load_catalog()
except Exception as e:
    st.error(f"Could not load clean_clothing_catalog.csv: {e}")
    st.stop()

st.markdown("""
<div class="hero">
  <h1>👕 CapClot</h1>
  <p>Your simple clothing recommendation assistant. Choose your preferences and discover matching styles.</p>
</div>
""", unsafe_allow_html=True)

st.write("### Find clothing that matches your style")
a, b, c, d = st.columns(4)
categories = ["Any"] + sorted(catalog["category"].dropna().astype(str).unique().tolist())
colors = ["Any"] + sorted(catalog["color"].dropna().astype(str).unique().tolist())
occasions = ["Any"] + sorted(catalog["occasion"].dropna().astype(str).unique().tolist())
styles = ["Any"] + sorted(catalog["style"].dropna().astype(str).unique().tolist())

with a:
    category = st.selectbox("Category", categories)
with b:
    color = st.selectbox("Preferred color", colors)
with c:
    occasion = st.selectbox("Occasion", occasions)
with d:
    style = st.selectbox("Style", styles)

e, f = st.columns([2, 1])
with e:
    max_budget = st.slider("Maximum budget (₹)", min_value=0,
                           max_value=max(3000, int(catalog["price"].max())),
                           value=min(1500, max(3000, int(catalog["price"].max()))), step=100)
with f:
    top_n = st.selectbox("Number of recommendations", [3, 5, 8, 10], index=1)

if st.button("✨ Find my clothing", type="primary", use_container_width=True):
    results = recommend_clothing(catalog, category, color, occasion, style, max_budget, top_n)
    st.session_state["recommendations"] = results

if "recommendations" in st.session_state:
    results = st.session_state["recommendations"]
    # Re-check budget/preferences when the user changes inputs and presses the button.
    if results.empty:
        st.warning("No items fit that budget. Try increasing your maximum budget.")
    else:
        st.write("### Recommended for you")
        st.caption("Results are ranked using simple preference-match scores. This demo uses a small sample catalog.")
        m1, m2, m3 = st.columns(3)
        m1.metric("Items found", len(results))
        m2.metric("Lowest price", f"₹{results['price'].min():,.0f}")
        m3.metric("Highest match score", int(results["match_score"].max()))
        cards = st.columns(3)
        for i, (_, item) in enumerate(results.iterrows()):
            with cards[i % 3]:
                with st.container(border=True):
                    st.markdown(f"#### {item['name']}")
                    st.markdown(f"**₹{item['price']:,.0f}**")
                    st.write(f"**Category:** {item['category']}")
                    st.write(f"**Color:** {item['color']}")
                    st.write(f"**Occasion:** {item['occasion']}")
                    st.write(f"**Style:** {item['style']}")
                    st.caption(f"Match score: {item['match_score']} · {item['match_reasons'] or 'Budget/catalog match'}")
        st.download_button("Download these recommendations as CSV",
                           data=results.to_csv(index=False).encode("utf-8"),
                           file_name="my_clothing_recommendations.csv",
                           mime="text/csv")
else:
    st.info("Choose your preferences above, then click **Find my clothing**.")
    st.write("### Explore the catalog")
    st.dataframe(catalog[["name", "category", "color", "occasion", "style", "price"]],
                 use_container_width=True, hide_index=True)

with st.expander("About this project"):
    st.write("CapClot is a beginner-friendly content-based clothing recommender built with Python, Pandas, and Streamlit. It uses hand-designed match scores, not a trained machine-learning model or live store inventory.")
